# tools

-node version 16.16.0

# install project

npm install || npm install --force

# run project

npm start

# port default 8080

## scan qr code

http://localhost:8080/scan
